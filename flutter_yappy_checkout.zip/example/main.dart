import 'package:flutter/material.dart';
import 'package:flutter_yappy_checkout/flutter_yappy_checkout.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yappy Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ejemplo Yappy Checkout')),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            final result = await Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const YappyCheckout(
                  amount: 12.5,
                  reference: 'BOOKING-1234567890',
                  description: 'Pago de reserva',
                  apiUrl: 'https://tudominio.com/api/yappy/create',
                  aliasYappy: '67845176',
                ),
              ),
            );
            print(result);
          },
          child: const Text('Pagar con Yappy'),
        ),
      ),
    );
  }
}
