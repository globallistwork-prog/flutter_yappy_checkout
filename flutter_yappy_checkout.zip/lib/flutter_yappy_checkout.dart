library flutter_yappy_checkout;

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class YappyCheckout extends StatefulWidget {
  final double amount;
  final String reference;
  final String description;
  final String apiUrl;
  final String aliasYappy;

  const YappyCheckout({
    Key? key,
    required this.amount,
    required this.reference,
    required this.description,
    required this.apiUrl,
    required this.aliasYappy,
  }) : super(key: key);

  @override
  State<YappyCheckout> createState() => _YappyCheckoutState();
}

class _YappyCheckoutState extends State<YappyCheckout> {
  late final WebViewController _controller;
  bool isLoading = true;
  String? paymentUrl;
  String? transactionId;

  @override
  void initState() {
    super.initState();
    _createYappyOrder();
  }

  Future<void> _createYappyOrder() async {
    final response = await http.post(
      Uri.parse(widget.apiUrl),
      headers: {'Accept': 'application/json'},
      body: {
        'amount': widget.amount.toString(),
        'reference': widget.reference,
        'description': widget.description,
        'alias_yappy': widget.aliasYappy,
      },
    );

    final res = jsonDecode(response.body);

    if (response.statusCode == 200 && res['status'] == true) {
      paymentUrl = res['data']['payment_url'];
      transactionId = res['data']['transaction_id'];

      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(
          NavigationDelegate(
            onNavigationRequest: (NavigationRequest request) {
              final url = request.url.toLowerCase();
              if (url.contains('success') || url.contains('retorno')) {
                Navigator.pop(context, {'transaction_id': transactionId});
                return NavigationDecision.prevent;
              }
              return NavigationDecision.navigate;
            },
          ),
        )
        ..loadRequest(Uri.parse(paymentUrl!));

      setState(() => isLoading = false);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(res['message'] ?? 'Error creando orden')),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pago con Yappy')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : WebViewWidget(controller: _controller),
    );
  }
}
